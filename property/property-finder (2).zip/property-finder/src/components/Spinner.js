import React from "react";
import "../styles/spinner.css";
const Spinner = () => {
  return (
    // <div className="spinner-border text-primary" role="status">
    //   <span className="visually-hidden">Loading...</span>
    // </div>
    <div className="loader"></div>
  );
};

export default Spinner;